== iOS-Inspired Theme for jQuery Mobile

NOTE: The method of hard coding the back button syntax is no longer required and will in fact break.